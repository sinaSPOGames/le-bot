module.exports ={
    name: 'ily',
    run: async(client, message) => {
        message.reply('Kuro Kami is my Daddy❤️')
    }
}