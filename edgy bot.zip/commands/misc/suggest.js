const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "suggest",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        const questions = [
            "ok so what do you suggest we should add or remove from the server?",
            "why should we?",
        ];

        let collectCounter = 0;
        let endCounter = 0;

        const filter = (m) => m.author.id === message.author.id;

        const appStart = await message.author.send(questions[collectCounter++]);
        const channel = appStart.channel;

        const collector = channel.createMessageCollector(filter);

        collector.on("collect", () => {
            if(collectCounter < questions.length) {
                channel.send(questions[collectCounter++]);
            } else {
                channel.send("ok I sent the sugestion to the staff");
                collector.stop("fulfilled");
            }
        });

        const appsChannel = client.channels.cache.get('1049001474308460585');
        collector.on("end", (collected, reason) => {
          if (reason === "fulfilled") {
            let index = 1;
            const mappedResponses = collected
            .map((msg) => {
                return `${index++}) ${questions[endCounter++]}\n-> ${msg.content}`;
            })
            .join("\n\n");
          
           appsChannel.send(
            new MessageEmbed()
            .setAuthor(
                message.author.tag, 
                message.author.displayAvatarURL({ dynamic: true})
                )
            .setTitle('new complaint!')
            .setImage('https://discord.com/channels/987171927099588668/987181759965847623/993300733548048525')
            .setColor('BLACK')
            .setDescription(mappedResponses)
            .setTimestamp()
           )
          
        }})}}
