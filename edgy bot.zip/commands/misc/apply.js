const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "apply",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        const questions = [
            "please note any bullshit answers will leave your application null - in - void type YES if you understand",
            "How old are you?",
            "where are you from?",
            "do you have any experience as a mod/admin in a discord server?",
            "why should we pick you?",
            "whats your gender?",            
        ];

        let collectCounter = 0;
        let endCounter = 0;

        const filter = (m) => m.author.id === message.author.id;

        const appStart = await message.author.send(questions[collectCounter++]);
        const channel = appStart.channel;

        const collector = channel.createMessageCollector(filter);

        collector.on("collect", () => {
            if(collectCounter < questions.length) {
                channel.send(questions[collectCounter++]);
            } else {
                channel.send("ok I send your application!");
                collector.stop("fulfilled");
            }
        });

        const appsChannel = client.channels.cache.get('1084692414092025897');
        collector.on("end", (collected, reason) => {
          if (reason === "fulfilled") {
            let index = 1;
            const mappedResponses = collected
            .map((msg) => {
                return `${index++}) ${questions[endCounter++]}\n-> ${msg.content}`;
            })
            .join("\n\n");
          
           appsChannel.send(
            new MessageEmbed()
            .setAuthor(
                message.author.tag, 
                message.author.displayAvatarURL({ dynamic: true})
                )
            .setTitle('New Application!')
            .setImage('https://cdn.discordapp.com/attachments/1021869174542307348/1046439455050956840/0D44BA1D-AD10-4BB4-83A1-5683DC48E42.gif')
            .setColor('BLACK')
            .setDescription(mappedResponses)
            .setTimestamp()
           )
          
        }})}}
