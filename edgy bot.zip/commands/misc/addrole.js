const { Message } = require('discord.js')

module.exports = {
    name : 'addrole',
    run : async(client, message, args) => {
        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('Nigga stop using shit you aint got perms for😂')  

        const target = message.mentions.members.first()
        if(!target) return message.channel.send('who am I giving a role to?')
        const role = message.mentions.roles.first()
        if(!role) return message.channel.send('What role am I giving?')
        
        await target.roles.add(role)
        message.channel.send(`${target.user.username} got a role!`)
    }
}