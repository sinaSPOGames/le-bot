const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "complaint",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        const questions = [
            "whats your complaint? please state it in full detail",            
        ];

        let collectCounter = 0;
        let endCounter = 0;

        const filter = (m) => m.author.id === message.author.id;

        const appStart = await message.author.send(questions[collectCounter++]);
        const channel = appStart.channel;

        const collector = channel.createMessageCollector(filter);

        collector.on("collect", () => {
            if(collectCounter < questions.length) {
                channel.send(questions[collectCounter++]);
            } else {
                channel.send("ok ive notified the staff they'll let you know what'll happen soon enough");
                collector.stop("fulfilled");
            }
        });

        const appsChannel = client.channels.cache.get('1084692414092025897');
        collector.on("end", (collected, reason) => {
          if (reason === "fulfilled") {
            let index = 1;
            const mappedResponses = collected
            .map((msg) => {
                return `${index++}) ${questions[endCounter++]}\n-> ${msg.content}`;
            })
            .join("\n\n");
          
           appsChannel.send(
            new MessageEmbed()
            .setAuthor(
                message.author.tag, 
                message.author.displayAvatarURL({ dynamic: true})
                )
            .setTitle('new complaint!')
            .setImage('https://cdn.discordapp.com/attachments/987181759965847623/991747851472338944/IMG_0372.jpeg?size=4096')
            .setColor('BLACK')
            .setDescription(mappedResponses)
            .setTimestamp()
           )
          
        }})}}
