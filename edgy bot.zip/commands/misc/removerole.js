const { Message } = require('discord.js')

module.exports = {
    name : 'removerole',
    run : async(client, message, args) => {
        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('Nigga stop using shit you aint got perms for😂')  

        const target = message.mentions.members.first()
        if(!target) return message.channel.send('who am I taking a role from?')
        const role = message.mentions.roles.first()
        if(!role) return message.channel.send('What role am I taking?')
        
        await target.roles.remove(role)
        message.channel.send(`${target.user.username} lost a role!`)
    }
}