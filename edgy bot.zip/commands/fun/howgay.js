const Discord = require('discord.js')

module.exports = {
    name:"howgay",
    description: "howgay command",

    async run (bot, message, args) {
        let member = message.mentions.users.first() || message.author

        let rng = Math.floor(Math.random() * 200);

        const howgayembed = new Discord.MessageEmbed()
        .setTitle(`Gay Machine Calculator`)
        .setDescription(`${member.username} is ` + rng + "% gay🌈")
        .setColor("BLACK")
        message.channel.send(howgayembed);
    }}
