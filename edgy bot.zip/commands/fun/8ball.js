const Discord = require('discord.js')

module.exports = {
    name:"8b",
    description: "8ball command",

    async run(bot, message, args) {
        if(!args[0]) return message.reply('gimme a full question dumbass')
        let replies = ["yes", "a pretty decent chance", "yes definitly", "duh of course", "no", "i dont wanna ruin the suprise", "LMFAO its the fact u thought I was gonna say yes", "nigga not in a million years", "fuck no", "quit asking me dumbass questions we both know the anser no", "never in life"]

        let result = Math.floor((Math.random() * replies.length));
        let question = args.slice().join(" ");

        let ballembed = new Discord.MessageEmbed()
        .setAuthor(`🎱 ${message.author.username}`)
        .setColor("BLACK")
        .addField("Question", question)
        .addField("Answer", replies[result])

        message.channel.send(ballembed)
    }
}