const Discord = require('discord.js')

module.exports = {
    name:"rizzcheck",
    description: "checks your rizz",

    async run (bot, message, args) {
        let member = message.mentions.users.first() || message.author

        let rng = Math.floor(Math.random() * 100);

        const penisembed = new Discord.MessageEmbed()
        .setTitle(`The Rizz Checkor`)
        .setDescription(`${member.username} has a rizz score of ` + rng + " ")
        .setColor("BLACK")
        message.channel.send(penisembed);
    }}