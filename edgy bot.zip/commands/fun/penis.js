const Discord = require('discord.js')

module.exports = {
    name:"penis",
    description: "penis size command",

    async run (bot, message, args) {
        let member = message.mentions.users.first() || message.author

        let rng = Math.floor(Math.random() * 12);

        const penisembed = new Discord.MessageEmbed()
        .setTitle(`Penis Size Calculator`)
        .setDescription(`${member.username} has a dick size of ` + rng + " inches")
        .setColor("BLACK")
        message.channel.send(penisembed);
    }}