const Discord = require('discord.js')

module.exports = {
    name:"iq",
    description: "iq command",

    async run (bot, message, args) {
        let member = message.mentions.users.first() || message.author

        let rng = Math.floor(Math.random() * 200);

        const iqembed = new Discord.MessageEmbed()
        .setTitle(`IQ Calculator`)
        .setDescription(`${member.username} has an IQ of ` + rng )
        .setColor("BLACK")
        message.channel.send(iqembed);
    }}