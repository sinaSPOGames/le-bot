const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "antivc",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        if(!message.member.hasPermission('MANAGE_ROLES')) return;
        
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!target) return message.reply('who u want me to keep out vc?');

        let role = message.guild.roles.cache.find((role) => role.name.toLowerCase() === 'antivc');
        if(!role) {
            try {
                message.channel.send('lemme make the role right quick');
                role = await message.guild.roles.create({
                    data: {
                        name: 'antivc',
                        permissions: []
                    }
                })

                message.guild.channels.cache.filter((c) => c.type === 'voice').forEach(async channel => {
                    await channel.createOverwrite(role, {
                        VIEW_CHANNEL: true,
                        CONNECT: false
                    })
                })

                message.channel.send('I created the role')
            }  catch (error) {
                console.log(error)
            }
        }
        await target.roles.add(role.id);
        message.channel.send(`${target} wont be joining vc no time soon`)
    }
}