const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "nuke",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('and for sum reason yo ass thought the command was gon work😂')
        if(!message.guild.me.hasPermission('MANAGE_CHANNELS')) return message.channel.send

        message.channel.clone().then((ch) => {
            ch.setParent(message.channel.parent.id);
            ch.setPosition(message.channel.position);
            message.channel.delete();

            ch.send("I just blew this bitch up")
        });
    }}