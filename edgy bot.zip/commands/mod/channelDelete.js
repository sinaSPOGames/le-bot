const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name: "delete",
    /**@param {Client} Client
     * @param {Message} message
     * @param {Stringp[]} args
     */
    run: async (client, message, args) => {
        if (!message.member.permissions.has("MANAGE_CHANNELS"))
        return message.reply("You aint got perms");

        const channelTarget = message.mentions.channels.first() || message.channel;
        
        channelTarget.delete()
        .then(ch => {
            message.author.send(`I deleted it`)
        })
    }
}