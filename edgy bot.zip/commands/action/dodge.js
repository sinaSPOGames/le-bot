const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'dodge',
    description: 'didge an attack',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/Jbs7HHHjCJcAAAAS/goku-super-instinct.gif",
            "https://media.tenor.com/B_aPfAHl76QAAAAS/dodge-dragon-ball.gif",
            "https://media.tenor.com/2_vHQgVBn0QAAAAM/ayanokoji-fight.gif",
            "https://media.tenor.com/CGUVzKSQc9IAAAAM/evade-dodge.gif",
            "https://media.tenor.com/rCk7iQ8ZaSwAAAAM/haku-naruto.gif",
            "https://media.tenor.com/yNWViAfiInkAAAAM/anime-fight.gif",
            "https://media.tenor.com/HhONdwOJ05EAAAAS/fast-bullets.gif",
            "https://media.tenor.com/qfLIj53iddEAAAAS/onepiece-kenbunshoku.gif",
            "https://media.tenor.com/xnIfuTrHUAQAAAAS/luffy-dodged.gif",
            "https://media.tenor.com/jEvVbMrTBPEAAAAS/dragon-ball-fight.gif",
        ]

        personDodged = message.mentions.users.first()
        if(personDodged){
            const DodgeEmbed = new Discord.MessageEmbed()
                .setTitle(`You Dodged ${personDodged.username} :tada:`)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(DodgeEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
