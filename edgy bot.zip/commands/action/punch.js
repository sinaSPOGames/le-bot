const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'punch',
    description: 'punch at people',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/puvkDAPIxaYAAAAM/kasumi-nakasu-punch.gif",
            "https://media.tenor.com/DKMb2QPU7aYAAAAM/rin243109-blue-exorcist.gif",
            "https://media.tenor.com/ObgxhbfdVCAAAAAM/luffy-anime.gif",
            "https://media.tenor.com/BESYHOr_4uIAAAAM/v9-fight.gif",
            "https://media.tenor.com/jMVkUG5ouL8AAAAS/punch-anime.gif",
            "https://media.tenor.com/xWqmJMePsqEAAAAS/weaboo-otaku.gif",
            "https://media.tenor.com/6pY8YkmSCpcAAAAS/shiki-granbell-shiki-punching.gif",
            "https://media.tenor.com/laW-dCBdPUgAAAAS/dragon-ball-super-goku.gif",
            "https://media.tenor.com/Tz95CKTac-YAAAAS/akagi-punch.gif",
            "https://media.tenor.com/Y_4_saaGYwUAAAAM/jujutsu-kaisen-mahito.gif",
        ]

        personPunch = message.mentions.users.first()
        if(personPunch){
            const PunchEmbed = new Discord.MessageEmbed()
                .setTitle(`You Punched ${personPunch.username} :punch: `)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(PunchEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
