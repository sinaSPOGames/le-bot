const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'fuck',
    description: 'fuck her',

    async run (bot, message, args) {
        images = [
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745525093146804/abffb3f9f347657740e39a337c39c159.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745525474836490/c84311b4e910abd748ed5fac5c0092c2.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745525869097051/79413ca5d1b3e8de58e56029a26a148f.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745526271754401/7ff589faca1c1962a300b64d7ef90417.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745526628266054/5077eeb12d92d9a6f5b4a110bebe2435.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745526993166377/369818a142dd1d12149511a70fe952f3.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745969978773675/e910d7df6cbbb99d893d39b529cd0584.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745970335285449/841be83f5b6fe5aa7995eae0f6584c2b.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745970792476762/0d33c460f8c7742dd21e3a336908e8c6.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745971241259138/01d69929301fdc08dacefc7a7fe748b7.gif",
            "https://cdn.discordapp.com/attachments/1069770602107375676/1070745971681656923/4af9406698f0cf7eb073f04c3457c6b8.gif",
            

            
            
        ]

        personFuck = message.mentions.users.first()
        if(personFuck){
            const FuckEmbed = new Discord.MessageEmbed()
                .setTitle(`You started fucking ${personFuck.username} :weary: `)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(FuckEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
