const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'smooch',
    description: 'kiss her',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/YHxJ9NvLYKsAAAAS/anime-kiss.gif",
            "https://media.tenor.com/jnndDmOm5wMAAAAM/kiss.gif",
            "https://media.tenor.com/dn_KuOESmUYAAAAM/engage-kiss-anime-kiss.gif",
            "https://media.tenor.com/fiafXWajQFoAAAAM/kiss-anime.gif",
            "https://media.tenor.com/b2q1WNG8zT8AAAAM/anime-kiss.gif",
            "https://media.tenor.com/Zv8hLi7cYh0AAAAM/kiss.gif",
            "https://media.tenor.com/t7CMvy0b8XsAAAAM/kiss-me.gif",
            "https://media.tenor.com/nLTnl9n9x1sAAAAM/anime-anime-kiss.gif",
            "https://media.tenor.com/-tntwZEqVX4AAAAM/anime-kiss.gif",
            "https://media.tenor.com/ZuZTRDf__hQAAAAM/kiss.gif",
        ]

        personSmooch = message.mentions.users.first()
        if(personSmooch){
            const SmoochEmbed = new Discord.MessageEmbed()
                .setTitle(`You Smooched ${personSmooch.username} :kiss: `)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(SmoochEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
