const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'laugh',
    description: 'laugh at people',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/9AtxAcky4NsAAAAM/jujutsu-kaisen.gif",
            "https://media.tenor.com/nqTDeAS9sL8AAAAM/fairy-tail-natsu.gif",
            "https://media.tenor.com/XQxOkKXFG7oAAAAM/satania-laugh.gif",
            "https://media.tenor.com/K6WDm9L78mgAAAAM/rezero-rem.gif",
            "https://media.tenor.com/9LVHHynKJ1IAAAAM/laugh-anime.gif",
            "https://media.tenor.com/CG8uhh9CoJcAAAAM/shikimori-shikimoris-not-just-cute.gif",
            "https://media.tenor.com/M8k9KK75_rQAAAAM/laugh-anime.gif",
            "https://media.tenor.com/IshwaWQy4I4AAAAM/anime-laugh.gif",
            "https://media.tenor.com/eOFR0yUSotEAAAAM/satania-laughing.gif",
            "https://media.tenor.com/dgJzIYUxgPsAAAAM/laugh-point-finger.gif",
        ]

        personLaugh = message.mentions.users.first()
        if(personLaugh){
            const LaughEmbed = new Discord.MessageEmbed()
                .setTitle(`You Laughed at ${personLaugh.username} :laughing:  `)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(LaughEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
