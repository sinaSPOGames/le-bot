const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'blush',
    description: 'blush at people',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/30a9CPebaZoAAAAS/koiseka-anime-blush.gif",
            "https://media.tenor.com/g8azBMokn4gAAAAC/koiseka-anime-blush.gif",
            "https://media.tenor.com/ZDHaRFy2CHQAAAAC/koiseka-anime-blush.gif",
            "https://media.tenor.com/gb0XchPkU2UAAAAC/koiseka-anime-blush.gif",
            "https://media.tenor.com/xDa7SdixrdIAAAAC/koiseka-anime-no.gif",
            "https://media.tenor.com/OJ7dWLRs3JAAAAAM/mizuhara-chizuru.gif",
            "https://media.tenor.com/daIZ-e7VvkwAAAAd/anime-blush.gif",
            "https://media.tenor.com/KDPRHWcjUY8AAAAC/yeison.gif",
            "https://media.tenor.com/QTIduAnZKBgAAAAM/cute-anime.gif",
            "https://media.tenor.com/yKtYfA0mizYAAAAC/my-dress-up-darling-anime-blush.gif",
        ]

        personBlush = message.mentions.users.first()
        if(personBlush){
            const BlushEmbed = new Discord.MessageEmbed()
                .setTitle(`You blushed at ${personBlush.username} ❤️`)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(BlushEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
