const Math = require('mathjs');
const Discord = require("discord.js");

module.exports = {
    name: 'hug',
    description: 'hug your friends',

    async run (bot, message, args) {
        images = [
            "https://media.tenor.com/J7eGDvGeP9IAAAAS/enage-kiss-anime-hug.gif",
            "https://media.tenor.com/kCZjTqCKiggAAAAM/hug.gif",
            "https://media.tenor.com/UUDWXyIeKvkAAAAM/hug.gif",
            "https://media.tenor.com/G_IvONY8EFgAAAAM/aharen-san-anime-hug.gif",
            "https://media.tenor.com/hacbVpDut3sAAAAM/hug.gif",
            "https://media.tenor.com/mB_y2KUsyuoAAAAM/cuddle-anime-hug.gif",
            "https://media.tenor.com/iyztKN68avcAAAAM/aharen-san-aharen-san-anime.gif",
            "https://media.tenor.com/4Bez5mC86CkAAAAM/hug.gif",
            "https://media.tenor.com/vpE5_F_oqmsAAAAM/run-hug-hug.gif",
            "https://media.tenor.com/FUgPm0LE9h0AAAAM/hug.gif"
        ]

        personHugged = message.mentions.users.first()
        if(personHugged){
            const hugEmbed = new Discord.MessageEmbed()
                .setTitle(`You hugged ${personHugged.username} ❤️`)
                .setImage(images[Math. floor(Math. random()*images. length)])
                .setTimestamp()
             message.channel.send(hugEmbed)
    }
    else{
        message.channel.send('try pinging someone in the server retard')
    }
}
}
